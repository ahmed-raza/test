<?php
  $hostname = 'localhost';
  $username = 'root';
  $password = '';
  $database = 'college';
  $connection = mysqli_connect($hostname, $username, $password, $database);
?>
