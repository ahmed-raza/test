<?php include 'header.php'; ?>
<div class="container">
	<table class="table">
		<tr>
			<th>SR</th>
			<th>Internal Receiving</th>
			<th>Date</th>
			<th>Department</th>
			<th>D Type</th>
			<th>Organization</th>
			<th>Organization Type</th>
			<th>File Num</th>
			<th>Subject</th>
			<th>File Name</th>
			<th>Status</th>
			<th>Actions</th>
		</tr>
	</table>
</div>