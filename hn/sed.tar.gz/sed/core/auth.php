<?php
  session_start(); // starts the login session
  include_once('database/connection.db.php');
  class Auth{
    public function login($username, $password){
      global $connection;
      if (!empty($username) && !empty($password)) {
        $query = "SELECT * FROM UserDetails WHERE username='$username' AND password='$password'";
        $result = mysqli_query($connection, $query);
        $result = mysqli_num_rows($result);
        if ($result == 1) {
          $_SESSION['login'] = $username;
          return true;
        }else{
          return false;
        }
      }else{
        return false;
      }
    }

    public function register(array $registration_data){
      global $connection;
      if (isset($registration_data)) {
        $username = $registration_data['username'];
        $fullname = $registration_data['fullname'];
        $password = $registration_data['password'];
        $email = $registration_data['email'];
        $query = "SELECT * FROM UserDetails WHERE username='$username' OR emailid='$email'";
        $result = mysqli_query($connection, $query);
        $result = mysqli_num_rows($result);
        if ($result == false) {
          $new_user = "INSERT INTO UserDetails (username,name,emailid,password) VALUES ('$username','$fullname','$email','$password')";
          $save_new_user = mysqli_query($connection, $new_user);
          if ($save_new_user) {
            return true;
          }else{
            return false;
          }
        }else{
          return false;
        }
      }else{
        return false;
      }
    }
  }
?>
