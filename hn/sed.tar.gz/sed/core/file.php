<?php
  session_start(); // starts the login session
  include_once('database/connection.db.php');
  class File{
  	public function addFile(array $fileData){
  		// Code to add file goes here
  	}
  }
?>