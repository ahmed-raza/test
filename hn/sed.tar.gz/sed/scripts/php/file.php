<?php
  include_once('core/file.php');
  if(isset($_POST['add_file'])){
  	$internal_receiving = $_POST['internal_receiving'];
  	$department = $_POST['department'];
  	$department_type = $_POST['department_type'];
  	$organization = $_POST['organization'];
  	$organization_type = $_POST['organization_type'];
  	$file_num = $_POST['file_num'];
  	$date = $_POST['date'];
  }
?>