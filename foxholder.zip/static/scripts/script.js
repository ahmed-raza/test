jQuery('document').ready(function() {

  jQuery('.form-container-1').foxholder({
    demo: 1,
  });

  jQuery('.form-container-2').foxholder({
    demo: 2,
  });

  jQuery('.form-container-3').foxholder({
    demo: 3,
  });

  jQuery('.form-container-4').foxholder({
    demo: 4,
  });

  jQuery('.form-container-5').foxholder({
    demo: 5,
  });

  jQuery('.form-container-6').foxholder({
    demo: 6,
  });

  jQuery('.form-container-7').foxholder({
    demo: 7,
  });

  jQuery('.form-container-8').foxholder({
    demo: 8,
  });

  jQuery('.form-container-9').foxholder({
    demo: 9,
  });

  jQuery('.form-container-10').foxholder({
    demo: 10,
  });

  jQuery('.form-container-11').foxholder({
    demo: 11,
  });

  jQuery('.form-container-12').foxholder({
    demo: 12,
  });

  jQuery('.form-container-13').foxholder({
    demo: 13,
  });

  jQuery('.form-container-14').foxholder({
    demo: 14,
  });

  jQuery('.form-container-15').foxholder({
    demo: 15,
  });

  jQuery('.form-container-ex').foxholder({
    demo: 3,
  });

});
